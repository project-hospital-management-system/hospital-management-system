<?php
return ['data_dir' => DATA_DIR];
