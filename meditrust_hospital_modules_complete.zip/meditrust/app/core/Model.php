<?php
declare(strict_types=1);

class Model
{
    protected PDO $db;

    public function __construct()
    {
        $this->db = db();
    }
}
