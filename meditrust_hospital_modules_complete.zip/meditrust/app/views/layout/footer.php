
  </main>

  <?php if (!empty($pageJs)): ?>
    <script src="<?php echo BASE_URL; ?>/assets/js/<?php echo htmlspecialchars($pageJs); ?>"></script>
  <?php endif; ?>
</body>
</html>
