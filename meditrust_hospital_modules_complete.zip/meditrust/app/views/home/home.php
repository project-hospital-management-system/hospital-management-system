<h1>Welcome to MediTrust MVC</h1>
<p>All your features (16–20) are merged into one MVC project.</p>
<ul>
  <li><a href="<?php echo BASE_URL; ?>/emr">EMR</a></li>
  <li><a href="<?php echo BASE_URL; ?>/notifications">Notifications</a></li>
  <li><a href="<?php echo BASE_URL; ?>/reports">Reports & Analytics</a></li>
  <li><a href="<?php echo BASE_URL; ?>/telemedicine">Telemedicine</a></li>
  <li><a href="<?php echo BASE_URL; ?>/feedback">Feedback & Complaints</a></li>
</ul>
<p><strong>Next:</strong> If you want, I can convert your JS to call these API endpoints so everything becomes database-driven.</p>
